del "standard.zip"
tar.exe "--exclude=standard.zip" -a -cf standard.zip *