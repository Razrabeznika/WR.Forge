# Warnament mods

A mod is a ZIP archive that changes Warnament data. Only one custom mod can be active at a time. The Standard mod is used by default.

All players in a multiplayer game must use identical mod content. Saves are also tied to the active mod content.

## Quick start

1. Extract the Standard mod template into a separate folder.
2. Edit `info.txt` and the required HJSON files. Don't forget to change unique_id
3. Run `rebuild_mod.bat` or zip all files yourself.
4. Rename the generated `standard.zip`, for example to `my_mod.zip`.
5. Put the archive into the game's folder (Use the same way that used for maps and scenarios).
6. Launch Warnament, open the mod list in the main menu, and select the mod.
7. Restart Warnament again to apply it.

Windows:
```text
<Warnament directory>/my_mod.zip
```

Place the archive next to `Warnament.exe`.

Android:

```text
/storage/emulated/0/Android/data/com.ludenio.a7/files/my_mod.zip
```

Files must be stored directly at the ZIP root. `my_mod/info.txt` is incorrect. `info.txt` is correct.

## info.txt

This file is required:

```ini
name=My mod
author=Author
version=1
description=Mod description
unique_id=my_mod_01
```

- `version` must match the current mod support version. It is currently `1`.
- `unique_id` must be unique and remain unchanged between mod updates.
- A mod without `info.txt`, `unique_id`, or a supported version cannot be selected.

## Editable content

- `map.hjson` — border style and map colors.
- `resources.hjson` — resources, initial amounts, map spawning, and resource lens colors.
- `buildings.hjson` — buildings, levels, costs, inputs, and outputs.
- `technology.hjson` — the technology tree.
- Files containing `events` in their names — events.
- Files containing `decisions` in their names — decisions.
- `discontent.hjson` — discontent events and decisions.
- `icons/` — building and resource icons.
- `offer_images/` — event and decision images.
- `loading_screens/` — loading screens.

## Map

`map.hjson` replaces the complete Standard map settings. Keep all fields:

```hjson
{
  inland_borders: 2
  coastline_color: [16, 62, 89]
  water_color: [19, 49, 74]
  river_color: [40, 69, 94]
}
```

Colors use RGB values from `0` to `255`. Set `inland_borders` to `2` for dotted borders or `-1` for the Standard style.

## Resources

Example from `resources.hjson`:

```hjson
{
  resources: [
    {
      id: gold
      initial: 0
      extractable: true
      spawn_chance: 12
      spawn_min: 5000
      spawn_max: 18000
      color: [255, 255, 128]
    }
  ]
}
```

- `id` is required.
- `name` is an optional display text or translation key.
- `description` is an optional display text or translation key.
- `initial` is the initial resource amount.
- An extractable resource requires `extractable`, `spawn_chance`, `spawn_min`, and `spawn_max`.
- `color` — optional RGB values from `0` to `255`. Used by the resource lens. Recommended for extractable resources.
- An existing `id` completely replaces the Standard resource.
- A new `id` adds a resource.

Some standard resources cannot be removed by a mod.

## Buildings

Buildings are grouped into the sections used by `assets/mods/buildings.hjson`, such as `extraction`, `economy`, `production`, and `army`.

```hjson
{
  extraction: [{
    id: titanium_mine
    name: Titanium Mine
    description: Produces titanium from local deposits.
    lvl: [...]
  }]
}
```

Main fields:

- `id` — building identifier.
- `name` — optional display text or translation key.
- `description` — optional display text or translation key.
- `lvl` — list of building levels.
- `cost` — money required to build.
- `resource_cost` — resources required to build.
- `input` — resources consumed each turn.
- `output` — resources or effects produced each turn.

Common keys include `resource:gold`, `extract:gold`, `army:cavalry`, `population_increase`, `science`, `prestige`, and `gold`.

An existing `id` completely replaces the Standard building. A new `id` adds a building. To change one value, copy the complete building definition and edit that value.

Some standard buildings cannot be removed by a mod.

## Technologies

Example `technology.hjson`:

```hjson
{
  technologies: {
    t_3_10: {
      id: advanced_mining
      name: Advanced Mining
      requirements: [t_2_2]
      bonuses: [
        [resource_titanium]
        [building_titanium_mine_1]
      ]
    }
  }
}
```

- A position uses the `t_<column>_<row>` format.
- Columns range from `1` to `12`. Rows must be greater than `0`.
- `id` and `bonuses` are required.
- `name` is an optional display text or translation key.
- `requirements` contains required technology positions.
- `consequences_only: true` shows the technology only in Consequences mode.
- `resource_<id>` unlocks a resource.
- `building_<id>_<level>` unlocks a building level.

Research cost depends on the column: `5`, `10`, `15`, `20`, `30`, `40`, `60`, `80`, `100`, `120`, `160`, and `200` science points.

A node at an existing position completely replaces the Standard node. A new position adds a node. Every position listed in `requirements` must exist in the merged tree.

Standard technologies cannot be removed by a mod.

## Events and decisions

An event filename must contain `events` and end with `.hjson`. A decision filename must contain `decisions` and end with `.hjson`.

The active mod replaces the Standard event and decision lists. Keep the Standard files in your mod if their content is still required.

Main fields:

- `id`, `title`, `description` — translation keys.
- `image`, `icon` — identifiers from the built-in image lists.
- `requirements` — display requirements.
- `bonuses` — decision or event effects.
- `answer1`, `answer2` — event answers.
- `bonuses1`, `bonuses2` — answer effects.
- `repeatable: true` — allows a decision to be selected again.
- `delete_after_turns` — removes an event after the specified number of turns.
- `auto_answer1_if_ignored: true` — applies the first answer when the event is removed.
- `need_province: true` — requires the player to select a province.
- `highlight_vassals: true` — allows only vassals when selecting a province.

Available requirement subjects:

```text
political_institution, land_name, money, random_value, random_near_land,
no_enemy, building_exists, num_of_provinces, near_water, land_power,
independent_land, cooldown, GDT, CED
```

Available actions are `equal`, `not_equal`, `more`, and `less`. Supported actions depend on the subject. Copy a matching example from the Standard event and decision files.

`GDT` is current game data. `CED` is data saved by previous events. `%s` in `chat_message` is replaced with a land name.

Use existing bonuses from the Standard files. Unknown bonus identifiers do not work.

## Event images

Add or replace an event/decision image by placing an RGB JPG at `offer_images/<id>.jpg`. The filename without `.jpg` is its `image` identifier. IDs may contain letters, numbers, and underscores. Use **925×617** pixels. The maximum file size is 8 MB. If the mod does not provide an identifier, the built-in image is used.

Available `image` identifiers:

```text
barn, battleship, battleship2, border, burnt_letter, capital_is_down,
capital_of_science, communism, consequences, democracy, deserter,
diplomacy, empty_square, factory, fascism, fire_in_building, monarchy,
nuclear, officers_station, paganism, paranoia, political, rebellion,
space, technology, theocracy, theocracy_soldiers, trade_republic,
wunderwaffe
```

Available `icon` identifiers:

```text
diplomacy, discontent, losses, political, technology, border, check, industry
```

Chat message colors:

```text
standard, warning, danger, ally, pact, guarantee
```

## Building and resource icons

Default paths:

```text
icons/buildings/<building_id>.png
icons/resources/<resource_id>.png
```

A different path can be set with `icon`:

```hjson
{
  id: farm
  icon: icons/buildings/farm.png
}
```

Only PNG files are supported. Each file must be no larger than 1 MB. If a default mod icon is missing, Warnament uses its built-in icon.

## Loading screens

Each loading screen requires two files with the same name:

```text
loading_screens/1920x1080/<name>.png
loading_screens/1280x720/<name>.png
```

The image dimensions must exactly match the directory name. Each file must be no larger than 16 MB. Warnament randomly selects one loading screen from the active mod.

## Finding errors

The Mods menu lists every problem found in a mod. A red `[Error]` row cannot be selected. A yellow `[Warning]` row can still be selected.

Each issue is printed as `[file] path: message`, for example:

```text
[technology.hjson] t_2_1.requirements[1]: technology not found: t_9_9
[buildings.hjson] extraction[1].id: id is required
[events/custom_events1.hjson] [2].image: unknown image: foo
```

The game also writes the same list to the console and `debug_log`.

If the menu is not enough:

1. Close Warnament.
2. Delete the old `debug_log` file to avoid mixing old and new errors.
3. Rebuild the ZIP with `rebuild_mod.bat` or zip all files yourself.
4. Start Warnament and open the Mods menu.
5. Select the mod and read the Errors/Warnings panel.

Common problems:
- The mod is missing from the list — check `info.txt`, `version`, `unique_id`, the lowercase `.zip` extension, and the ZIP root.
- `unique_id is required` / `unsupported version` — `info.txt` is incomplete or outdated.
- `invalid position` — a technology key is not `t_<column>_<row>`.
- `technology not found` — `requirements` references a missing technology.
- `unknown resource` / `unknown building` — an id does not exist in the merged Standard + mod data.
- `must be an RGB array of 3 numbers` — `color` must be `[R, G, B]` with values from 0 to 255.
- `unknown image` — `image` is not a built-in id and there is no matching `offer_images/<id>.jpg`.
- `Both loading screen resolutions are required` — one loading screen version is missing.
- `expected 1920x1080` / `expected 1280x720` — PNG dimensions do not match the directory.

If a problem started after editing one file, restore its previous version and repeat the changes one at a time. The menu now reports every issue in the archive, not only the first one.
